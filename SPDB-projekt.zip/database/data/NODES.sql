INSERT INTO NODES (id, name, X, Y) VALUES
(1, 'City Hall', 100, 100),
(2, 'Park', 500, 200),
(3, 'Library', 900, 300),
(4, 'Museum', 200, 400),
(5, 'Train Station', 600, 500),
(6, 'Shopping Mall', 1000, 600),
(7, 'Hospital', 300, 700),
(8, 'University', 700, 800),
(9, 'Restaurant', 1100, 900),
(10, 'Cinema', 500, 1000);